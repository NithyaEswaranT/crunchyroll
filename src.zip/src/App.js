import React from 'react';

// import './App.css';

import Navbar from './Navbar/Navbar.js';
import Header from './Header/Header.js';
import Header1 from './Header/Header1.js';
import Section1 from './Section1/Section1.js';
import Section2 from './Section2/Section2.js';
import DropDown1 from './Dropdown1/Dropdown1.js';
import Sec2 from './Sec2/Sec2.js';
import Footer from './Footer/Footer.js';
import Section4 from './Section4/Section4.js';
import Sectionmbl4 from './Section4/Section4mbl.js';
import Section5 from './Section5/Section5.js';
import Section6 from './Section6/Section6.js';
import Section7 from './Section7/Section7.js';
import Sectionmbl5 from './Sectionmbl5/Sectionmbl5.js';
import Sl from './Sl/Sl.js';
import Sectionmbl1 from './Section1/Sectionmbl1.js';
import LinearIndeterminate from './Header/Header1.js';
function App() {
  return (
    <div className="App">
      <Navbar/>
   {/* <LinearIndeterminate/> */}
      <Header/>
      <Sectionmbl1/>
      <Section1/>
      <Section2/>
      <Sec2/>
      <Section4/>
      <Sectionmbl4/>
      <Section5/>
      <Sectionmbl5/>
      <Section6/>
<Section7/>
<Sl/>
      <Footer/>
    
   </div>

  );

}

export default App;
