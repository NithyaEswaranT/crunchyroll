
import React from "react";

function Section2(){
        return(
            <div class="bg-black text-white text-3xl">
            {/* <center>    <h1 class="pt-12 -ml-[820px] font-[Crunchyroll,Helvetica Neue,helvetica,sans-serif]">Subtitled in Hindi</h1>
            <p class="-ml-[761px] text-[16px] font-[Crunchyroll,Helvetica Neue,helvetica,sans-serif]">Watch these anime now subbed in Hindi!
            <p class="w-100% h-1 ml-[1100px] mt-2 bg-yellow-400  mr-[340px]"></p>


        
        </p></center> */}
        <img class="pt-3 ml-[330px] hidden 2xl:block" src="https://static.crunchyroll.com/fms/desktop_large/1050x350/16d1800f-7e3f-4ad4-9c48-166519a5bb77.png"></img>
        <img class="pt-3 -ml-[47px] hidden  2xl:hidden lg:block" src="https://static.crunchyroll.com/fms/desktop_large/1050x350/16d1800f-7e3f-4ad4-9c48-166519a5bb77.png"></img>
        <img class="pt-3 -ml-[27px] w-[1000px] pt-5 h-[200px]  md:hidden " src="https://static.crunchyroll.com/fms/desktop_large/1050x350/16d1800f-7e3f-4ad4-9c48-166519a5bb77.png"></img>

        <div class=" ml-[230px] grid gap-5 grid-cols-2 grid-rows-2"> 

        <div> <img class="w-[410px] hidden 2xl:block ml-[130px] mt-7" src="https://www.crunchyroll.com/imgsrv/display/thumbnail/1200x675/catalog/crunchyroll/cd726bd35ac8591bf6ce1a7779770def.jpe"></img></div>
          <div class="-ml-[200px] mt-14 hidden 2xl:block"> <h1>My Clueless First Friend</h1>
       <p class="text-gray-400 text-[14px]"><span class="text-teal-500">Series </span>. Sub&nbsp;|&nbsp;Dub</p>
          <p class="text-[15px] leading-6"> Fifth grader Nishimura isn’t too proud of her“Grim Reaper” moniker given by her <br></br> bullying schoolmates, but the new kid loves it. The once lonely target of everyone’s .....</p>
          <button class="bg-orange-500 text-black text-[14px] h-10 w-[200px] mt-5  pt-2 font-medium hover:bg-orange-400"><img class="ml-2" src="play.svg"></img> <p class="-mt-[31px] ml-4 ">START WATCHING S1 E1</p></button>
          <button class=" text-orange-500 border-amber-700 border-2 text-[14px] h-10 w-[200px] ml-3 mt-5  pt-2 font-medium hover:border-orange-400"><img class="ml-2" src="watch.svg"></img> <p class="-mt-[31px] ml-4 ">ADD TO WATCHLIST</p></button>
      
        </div>
        <div> <img class="w-[410px] hidden 2xl:block ml-[130px] mt-7" src="https://www.crunchyroll.com/imgsrv/display/thumbnail/1200x675/catalog/crunchyroll/d3e685e1d9c0e2eed32683ef2d373d6a.jpe"></img></div>
        <div class="-ml-[200px] mt-14 hidden 2xl:block"> <h1>MASHLE: MAGIC AND MUSCLES</h1>
          <p class="text-gray-400 text-[14px]"><span class="text-teal-500">Series </span>. Sub&nbsp;|&nbsp;Dub</p>
          <p class="text-[15px] leading-6">This is a world of magic. This is a world in which magic is casually used by everyone.<br></br> In a deep, dark forest in this world of magic, there is a boy who is singlemindedly .....</p>
          <button class="bg-orange-500 text-black text-[14px] h-10 w-[200px] mt-5  pt-2 font-medium hover:bg-orange-400"><img class="ml-2" src="play.svg"></img> <p class="-mt-[31px] ml-4 ">START WATCHING S1 E1</p></button>
          <button class=" text-orange-500 border-amber-700 border-2 text-[14px] h-10 w-[200px] ml-3 mt-5  pt-2 font-medium hover:border-orange-400"><img class="ml-2" src="watch.svg"></img> <p class="-mt-[31px] ml-4 ">ADD TO WATCHLIST</p></button>
      
        </div>
            </div>
             {/* ...........................................................................................laptop...................................................... */}
             <div class=" ml-[230px] grid gap-5 grid-cols-2 grid-rows-2"> 

<div> <img class="w-[360px] hidden 2xl:hidden lg:block -ml-[190px] mt-11" src="https://www.crunchyroll.com/imgsrv/display/thumbnail/1200x675/catalog/crunchyroll/cd726bd35ac8591bf6ce1a7779770def.jpe"></img></div>
  <div class="-ml-[210px] mt-14 hidden 2xl:hidden lg:block"> <h1>My Clueless First Friend</h1>
  <p class="text-gray-400 text-[14px]"><span class="text-teal-500">Series </span>. Sub&nbsp;|&nbsp;Dub</p>
  <p class="text-[15px] leading-6"> Fifth grader Nishimura isn’t too proud of her“Grim Reaper” moniker given by her <br></br> bullying schoolmates, but the new kid loves it. The once lonely target of everyone’s .....</p>
  <button class="bg-orange-500 text-black text-[14px] h-10 w-[200px] mt-5  pt-2 font-medium hover:bg-orange-400"><img class="ml-2" src="play.svg"></img> <p class="-mt-[31px] ml-4 ">START WATCHING S1 E1</p></button>
  <button class=" text-orange-500 border-amber-700 border-2 text-[14px] h-10 w-[200px] ml-3 mt-5  pt-2 font-medium hover:border-orange-400"><img class="ml-2" src="watch.svg"></img> <p class="-mt-[31px] ml-4 ">ADD TO WATCHLIST</p></button>

</div>
<div> <img class="w-[360px] hidden 2xl:hidden lg:block -ml-[189px] mt-11" src="https://www.crunchyroll.com/imgsrv/display/thumbnail/1200x675/catalog/crunchyroll/d3e685e1d9c0e2eed32683ef2d373d6a.jpe"></img></div>
<div class="-ml-[200px] mt-14 hidden 2xl:hidden lg:block"> <h1>MASHLE: MAGIC AND MUSCLES</h1>
  <p class="text-gray-400 text-[14px]"><span class="text-teal-500">Series </span>. Sub&nbsp;|&nbsp;Dub</p>
  <p class="text-[15px] leading-6">This is a world of magic. This is a world in which magic is casually used by everyone.<br></br> In a deep, dark forest in this world of magic, there is a boy who is singlemindedly .....</p>
  <button class="bg-orange-500 text-black text-[14px] h-10 w-[200px] mt-5  pt-2 font-medium hover:bg-orange-400"><img class="ml-2" src="play.svg"></img> <p class="-mt-[31px] ml-4 ">START WATCHING S1 E1</p></button>
  <button class=" text-orange-500 border-amber-700 border-2 text-[14px] h-10 w-[200px] ml-3 mt-5  pt-2 font-medium hover:border-orange-400"><img class="ml-2" src="watch.svg"></img> <p class="-mt-[31px] ml-4 ">ADD TO WATCHLIST</p></button>

</div>
    </div>

{/* <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<mbl><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<</mbl> */}
<div class=" grid gap-5 grid-cols-1 grid-rows-4"> 

<div> <img class="w-[390px] h-[230px] ml-4  md:hidden   mt-11" src="https://www.crunchyroll.com/imgsrv/display/thumbnail/1200x675/catalog/crunchyroll/cd726bd35ac8591bf6ce1a7779770def.jpe"></img></div>
  <div class="  md:hidden  ml-5"> <p class="text-[23px]">My Clueless First Friend</p>
  <div class="flex flex-cols">   <p class="text-gray-400 text-[14px]"><span class="text-teal-500">Series </span>. Sub&nbsp;|&nbsp;Dub</p><p><img class=" ml-[250px]  w-[24 px]"src="wish.svg"/></p></div>
  <p class="text-[14px] leading-5"> Fifth grader Nishimura isn’t too proud of her“Grim Reaper” moniker given by her  bullying schoolmates, but the new kid  it. The once lonely target of everyone’s .....</p>
  <button class="bg-orange-500 text-black text-[14px] h-10 w-[388px] mt-5  pt-2 font-medium hover:bg-orange-400"><img class="ml-[95px]" src="play.svg"></img> <p class="-mt-[31px] ml-4 ">START WATCHING S1 E1</p></button>

</div>
<div> <img class="w-[390px] md:hidden  h-[230px] -mt-[80px] ml-4" src="https://www.crunchyroll.com/imgsrv/display/thumbnail/1200x675/catalog/crunchyroll/d3e685e1d9c0e2eed32683ef2d373d6a.jpe"></img></div>
<div class="-mt-[130px] ml-5 md:hidden "> <p class="text-[23px]">MASHLE: MAGIC AND MUSCLES</p>
<div class="flex flex-cols">   <p class="text-gray-400 text-[14px]"><span class="text-teal-500">Series </span>. Sub&nbsp;|&nbsp;Dub</p><p><img class=" ml-[250px]  w-[24 px]"src="wish.svg"/></p></div>
  <p class="text-[14px] leading-5">This is a world of magic.This is a world in which magic is  used by everyone.In a deep, dark forest in this world of magic, there is a boy who is singlemindedly .....</p>
  <button class="bg-orange-500 text-black text-[14px] h-10 w-[390px] mt-5  pt-2 font-medium hover:bg-orange-400"><img class="ml-[95px]" src="play.svg"></img> <p class="-mt-[31px] ml-4 ">START WATCHING S1 E1</p></button>

</div>
    </div>
    <div class="md:hidden -mt-[155px] ">
                <div class="ml-5"> <img src="svgexport-30.svg"></img><p class="ml-7 -mt-8">New Episodes</p></div>
             <img class="-mt-[28px] ml-[370px]"src="svgexport-31.svg"></img>
                <p class="w-100% h-1 ml-[23px] mt-6 bg-orange-500  mr-[20px]"></p>
                <h1 class="text-[23px]  mt-2 ml-[33px]">Today</h1>
            <p class="w-100% h h-[2px] ml-[25px] mt-2 bg-slate-500  mr-[22px]"></p>
            <div class="ml-[230px] grid  grid-cols-1 "> 
              <div>  <button>
                 <img  class="w-[140px] -ml-[205px] -mt-[90px]"src="https://www.crunchyroll.com/imgsrv/display/thumbnail/320x180/catalog/crunchyroll/6fc32f0b24ef2dd7c9e897dced82dc72.jpe"></img>
                 <p class="text-[15px] font-medium leading-5 -ml-[50px] text-left -mt-[80px]" >(Dubs)The Café Terrace <br></br>and Its Goddesses</p>
                 <p class="text-gray-400 text-[14px]  -ml-[206px] -mt-2"> 2 Episodes</p>
                 <p class="text-gray-400 text-[14px] ml-[20px] -mt-3"> Sub&nbsp;|&nbsp;Dub <span class="text-teal-500 ml-[44px]">3:00am </span> </p>
                 </button> </div>
              <div> <button>
                 <img  class="w-[140px] -ml-[205px]  mt-4"src="https://www.crunchyroll.com/imgsrv/display/thumbnail/1200x675/catalog/crunchyroll/d3e685e1d9c0e2eed32683ef2d373d6a.jpe   "></img>
                 <p class="text-[14px] font-medium leading-5 -ml-[55px] text-left -mt-[80px]" >(Dubs)MASHLE: MAGIC<br></br> AND MUSCLES</p>
                 <p class="text-gray-400 text-[14px]  -ml-[185px] -mt-2"> 8 Episodes</p>
                 <p class="text-gray-400 text-[14px] -ml-[10px] -mt-3"> Sub&nbsp;|&nbsp;Dub <span class="text-teal-500 ml-[44px]">1:00am </span> </p>
                 </button>  </div>
              
            </div> 
            <h1 class="text-[23px]  mt-2 ml-[33px]">Yesterday</h1>
            <p class="w-100% h h-[2px] ml-[25px] mt-2 bg-slate-500  mr-[22px]"></p>
            <div class="ml-[230px] grid  text-left  grid-rows-2"> 
            
              <div>  <button>
                 <img  class="w-[140px] -ml-[205px] -mt-[90px]"src="https://www.crunchyroll.com/imgsrv/display/thumbnail/320x180/catalog/crunchyroll/6fc32f0b24ef2dd7c9e897dced82dc72.jpe"></img>
                 <p class="text-[15px] font-medium leading-5 -ml-[50px] text-left -mt-[80px]" >(Dubs)The Café Terrace <br></br>and Its Goddesses</p>
                 <p class="text-gray-400 text-[14px]  -ml-[206px] -mt-2">  Episodes 3</p>
                 <p class="text-gray-400 text-[14px] ml-[20px] -mt-3"> Subtitled <span class="text-teal-500 ml-[44px]">3:00am </span> </p>
                 </button> </div>
               
              <div ><button>
                 <img  class="w-[140px] -ml-[205px]  mt-4"src="https://www.crunchyroll.com/imgsrv/display/thumbnail/320x180/catalog/crunchyroll/e927496ff24c95e32084e7c17153de6a.jpe  "></img>
                 <p class="text-[14px] font-medium leading-5 -ml-[55px] text-left -mt-[80px]" >(Dubs)The Daily Life of the <br></br>Immortal King(Hindi Dub)</p>
                 <p class="text-gray-400 text-[14px]  -ml-[185px] -mt-2">  Episodes 4</p>
                 <p class="text-gray-400 text-[14px] -ml-[10px] -mt-3">Subtitled <span class="text-teal-500 ml-[44px]">1:00am </span> </p>
                 </button>  </div>
              
                 </div>
                 <button class="bg-slate-700 w-[385px] text-sm font-medium ml-[23px] h-[40px] ">
                SHOW MORE
            </button>
            </div>
        {/* ....................................................new2 sec.............................     */}
            <div class="hidden 2xl:block">
            <div class="hidden 2xl:block">
                <div class="ml-[360px] mt-11"> <img src="svgexport-30.svg"></img><h1 class="ml-7 -mt-8">New Episodes</h1></div>
                <p class="text-sm font-medium text-slate-300 ml-[1200px]  -mt-[30px]">VIEW RELEASE CALENDER <img class="-mt-[20px] ml-[170px]"src="svgexport-31.svg"></img></p>
                <p class="w-100% h-1 ml-[360px] mt-6 bg-orange-500  mr-[340px]"></p>
            
            </div>
            
            
            <h1 class="text-[23px]  mt-2 ml-[363px]">Today</h1>
            <p class="w-100% h-1 ml-[360px] mt-2 bg-slate-500  mr-[340px]"></p>
            <div class="ml-[230px] grid  grid-cols-3 "> 
              <div>  <button>
                 <img  class="w-[140px] ml-[140px] -mt-[90px]"src="https://www.crunchyroll.com/imgsrv/display/thumbnail/320x180/catalog/crunchyroll/6fc32f0b24ef2dd7c9e897dced82dc72.jpe"></img>
                 <p class="text-[15px] font-medium leading-5 ml-[290px] -mt-[80px]" >(Dubs)The Café Terrace <br></br>and Its Goddesses</p>
                 <p class="text-gray-400 text-[14px]  ml-[210px] -mt-2"> 2 Episodes</p>
                 <p class="text-gray-400 text-[14px] ml-[290px] -mt-3"> Sub&nbsp;|&nbsp;Dub <span class="text-teal-500 ml-[44px]">3:00am </span> </p>
                 </button> </div>
              <div> <button>
                 <img  class="w-[140px]  mt-6"src="https://www.crunchyroll.com/imgsrv/display/thumbnail/1200x675/catalog/crunchyroll/d3e685e1d9c0e2eed32683ef2d373d6a.jpe   "></img>
                 <p class="text-[14px] font-medium leading-5 ml-[150px] -mt-[80px]" >(Dubs)MASHLE: MAGIC<br></br> AND MUSCLES</p>
                 <p class="text-gray-400 text-[14px]  ml-[70px] -mt-2"> 8 Episodes</p>
                 <p class="text-gray-400 text-[14px] ml-[150px] -mt-3"> Sub&nbsp;|&nbsp;Dub <span class="text-teal-500 ml-[44px]">1:00am </span> </p>
                 </button>  </div>
              <div>  <button>
                 <img  class="w-[140px] -ml-[140px] mt-6"src="https://www.crunchyroll.com/imgsrv/display/thumbnail/320x180/catalog/crunchyroll/059e96ab752246038e308868e3dc5b1c.jpe"></img>
                 <p class="text-[14px] font-medium leading-5 -ml-[10px] -mt-[80px]" >(Dubs)My One-Hit Kill <br></br>Sister</p>
                 <p class="text-gray-400 text-[14px] -ml-[70px]  -mt-2"> 4 Episodes</p>
                 <p class="text-gray-400 text-[14px] ml-[20px] -mt-3"> Sub&nbsp;|&nbsp;Dub <span class="text-teal-500 ml-[44px]">12:30am </span> </p>
                 </button> </div>
            </div> 
            <h1 class="text-[23px] mt-2 ml-[363px] hidden 2xl:block">Yesterday</h1>
            <p class="w-100% h-1 ml-[360px] mt-2 bg-slate-500  mr-[340px]"></p>
            <div class="ml-[230px] grid  text-left grid-cols-3 grid-rows-2 "> 
              <div>  <button>
                 <img  class="w-[140px] ml-[140px] -mt-[90px]"src="https://www.crunchyroll.com/imgsrv/display/thumbnail/320x180/catalog/crunchyroll/6fc32f0b24ef2dd7c9e897dced82dc72.jpe"></img>
                 <p class="text-[15px] font-medium leading-5 ml-[290px] -mt-[80px]" >The Café Terrace <br></br>and Its Goddesses</p>
                 <p class="text-gray-400 text-[14px]  ml-[210px] -mt-2"> 2 Episodes</p>
                 <p class="text-gray-400 text-[14px] ml-[290px] -mt-3"> Subtitled <span class="text-teal-500 ml-[44px]">3:00am </span> </p>
                 </button> </div>
              <div> <button>
                 <img  class="w-[140px]  mt-6"src="https://www.crunchyroll.com/imgsrv/display/thumbnail/1200x675/catalog/crunchyroll/d3e685e1d9c0e2eed32683ef2d373d6a.jpe   "></img>
                 <p class="text-[14px] font-medium leading-5 ml-[110px] -mt-[80px]" >MASHLE: MAGIC<br></br> AND MUSCLES</p>
                 <p class="text-gray-400 text-[14px]  ml-[70px] -mt-2"> 8 Episodes</p>
                 <p class="text-gray-400 text-[14px] ml-[150px] -mt-3"> Subtitled <span class="text-teal-500 ml-[44px]">1:00am </span> </p>
                 </button>  </div>
              <div>  <button>
                 <img  class="w-[140px] -ml-[140px] mt-6"src="https://www.crunchyroll.com/imgsrv/display/thumbnail/320x180/catalog/crunchyroll/059e96ab752246038e308868e3dc5b1c.jpe"></img>
                 <p class="text-[14px] font-medium leading-5 -ml-[40px] -mt-[80px]" >My One-Hit Kill <br></br>Sister</p>
                 <p class="text-gray-400 text-[14px]  -ml-[70px] -mt-2"> 4 Episodes</p>
                 <p class="text-gray-400 text-[14px] ml-[20px] -mt-3"> Subtitled <span class="text-teal-500 ml-[44px]">12:30am </span> </p>
                 </button> </div>
                 <div>  <button>
                 <img  class="w-[140px] ml-[140px] -mt-[90px]"src="https://www.crunchyroll.com/imgsrv/display/thumbnail/320x180/catalog/crunchyroll/e927496ff24c95e32084e7c17153de6a.jpe"></img>
                 <p class="text-[14px] font-medium leading-5 ml-[290px] -mt-[80px]" >(Dubs)The Daily Life of the <br></br>Immortal King(Hindi Dub) </p>
                 <p class="text-gray-400 text-[14px]  ml-[210px] -mt-2"> 2 Episodes</p>
                 <p class="text-gray-400 text-[14px] ml-[290px] -mt-3">Dubbed <span class="text-teal-500 ml-[44px]">3:00am </span> </p>
                 </button> </div>
              <div> <button>
                 <img  class="w-[140px]  mt-6"src="https://www.crunchyroll.com/imgsrv/display/thumbnail/320x180/catalog/crunchyroll/82a3403c073edde0703175ad8c0f9bee.jpe"></img>
                 <p class="text-[14px] font-medium leading-5 ml-[150px] -mt-[80px]" >(Dubs)Mobile Suit<br></br>Gundam: The Witch from<br></br>Mercury</p>
                 <p class="text-gray-400 text-[14px]  ml-[60px] -mt-2"> 8 Episodes</p>
                 <p class="text-gray-400 text-[14px] ml-[150px] -mt-3"> Sub&nbsp;|&nbsp;Dub <span class="text-teal-500 ml-[44px]">1:00am </span> </p>
                 </button>  </div>
              <div>  <button>
                 <img  class="w-[140px] -ml-[140px] mt-6"src="https://www.crunchyroll.com/imgsrv/display/thumbnail/320x180/catalog/crunchyroll/dab93fca49a0a567cdecf7c52dc81e24.jpe"></img>
                 <p class="text-[14px] font-medium leading-5 ml-[20px] -mt-[80px]" >(Dubs)Yuri Is My Job!</p>
                 <p class="text-gray-400 text-[14px] -ml-[70px]  -mt-2"> 4 Episodes</p>
                 <p class="text-gray-400 text-[14px] ml-[20px] -mt-3"> Sub&nbsp;|&nbsp;Dub <span class="text-teal-500 ml-[44px]">12:30am </span> </p>
                 </button> </div>
            </div>
            <button class="bg-slate-700 w-[1050px] text-sm font-medium ml-[359px] h-[40px] hidden 2xl:block">
                SHOW MORE
            </button>
            </div>
            </div>
          
        );
    }

export default Section2;