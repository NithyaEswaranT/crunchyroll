export const data=[
    {
    id:1,
    img:'https://www.crunchyroll.com/imgsrv/display/thumbnail/240x360/catalog/crunchyroll/057908db709dec0de317006c86c0363e.jpe',
    type:"Buddy Daddies",
    t:"Series ",
    t1:". Sub | Dub"

    },

    {
    id:1,
    img:'https://www.crunchyroll.com/imgsrv/display/thumbnail/240x360/catalog/crunchyroll/1500ddfac4a1ffbc767603fcac1b9b2a.jpe',
      type:"Ranking of Kings",
     t:"Series ",
    t1:". Sub | Dub"
    },

    {
    id:1,
    img:'https://www.crunchyroll.com/imgsrv/display/thumbnail/240x360/catalog/crunchyroll/689e2efcf9f192ba6c0f7a538ee99027.jpe',
      type:"SPY x FAMILY",
     t:"Series ",
    t1:". Sub | Dub"
    },

    {
    id:1,
    img:'https://www.crunchyroll.com/imgsrv/display/thumbnail/240x360/catalog/crunchyroll/251524e3b5517b689317437d881eccf0.jpe',
      type:"My Hero Academia",
     t:"Series ",
    t1:". Sub | Dub"
    },

    {
    id:1,
    img:'https://www.crunchyroll.com/imgsrv/display/thumbnail/240x360/catalog/crunchyroll/e2640ec6f13f38927422c0841c924225.jpe',
      type:"THE PROMISED NEVERLAND",
     t:"Series ",
    t1:". Sub | Dub"
    },

    {
    id:1,
    img:'https://www.crunchyroll.com/imgsrv/display/thumbnail/240x360/catalog/crunchyroll/fbc4e0b1229ed0aff611ac46adb19b33.jpe',
      type:"Kakushigoto",
     t:"Series ",
    t1:". Sub | Dub"
    },

    {
    id:1,
    img:'https://www.crunchyroll.com/imgsrv/display/thumbnail/240x360/catalog/crunchyroll/1d35d24ebe5c927a52faf0fd9657cc3a.jpe',
      type:"A Herbivorous Dragon",
     t:"Series ",
    t1:". Sub | Dub"
    }
]

export const data2 = [
    {
        id:1,
    img:'https://www.crunchyroll.com/imgsrv/display/thumbnail/240x360/catalog/crunchyroll/abce57c319a2ea344c47e1e8afe45ff4.jpe',
    type:"MASHLE: MAGIC AND MUSCLES",
    t:"Series ",
    t1:". Sub | Dub"

    },

    {
    id:1,
    img:'https://www.crunchyroll.com/imgsrv/display/thumbnail/240x360/catalog/crunchyroll/2a8442e728c9e6c65da385548c9bbd71.jpe',
      type:"The Legendary Hero is Dead!",
     t:"Series ",
    t1:". Sub | Dub"
    },

    {
    id:1,
    img:'https://www.crunchyroll.com/imgsrv/display/thumbnail/240x360/catalog/crunchyroll/40af4cb42899f482e820db1eab3e2f23.jpe.jpe',
      type:"KamiKatsu: Working for God in a Godless World",
     t:"Series ",
    t1:". Sub | Dub"
    },

    {
    id:1,
    img:'https://www.crunchyroll.com/imgsrv/display/thumbnail/240x360/catalog/crunchyroll/93572bc2f9b6d753fa1b1f63391841ee.jpe',
      type:"A Galaxy Next Door",
     t:"Series ",
    t1:". Sub | Dub"
    },

    {
    id:1,
    img:'https://www.crunchyroll.com/imgsrv/display/thumbnail/240x360/catalog/crunchyroll/3c9bebb79d5abf889928349df37a42b0.jpe',
      type:"Dead Mount Death Play",
     t:"Series ",
    t1:". Sub | Dub"
    },

    {
    id:1,
    img:'"https://www.crunchyroll.com/imgsrv/display/thumbnail/240x360/catalog/crunchyroll/c06634d2f00bb70ba40c6794f72550e3.jpe',
      type:"My One-Hit Kill Sister",
     t:"Series ",
    t1:". Sub | Dub"
    },

    {
    id:1,
    img:'"https://www.crunchyroll.com/imgsrv/display/thumbnail/240x360/catalog/crunchyroll/6b943219816421cd2d88228959e06d86.jpe',
      type:" Skip and Loafer",
     t:"Series ",
    t1:". Sub | Dub"
    }   
   

]


